﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1MiguelPelaezDuro.Domain
{
    public class Trabajo
    {
        public int horas { get; set; }
        public String trabajoHecho { get; set; }
        public Double precio { get; set; }
        public String estado { get; set; }
        public Trabajo()
        {

        }
        public Trabajo(int horas, string trabajoHecho, double precio, bool estado)
        {
            this.horas = horas;
            this.trabajoHecho = trabajoHecho;
            this.precio = precio;
            this.estado = "En curso";
        }
    }
}
