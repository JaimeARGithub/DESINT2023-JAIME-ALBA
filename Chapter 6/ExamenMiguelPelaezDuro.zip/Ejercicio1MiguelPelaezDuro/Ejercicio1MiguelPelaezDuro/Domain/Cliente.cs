﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1MiguelPelaezDuro.Domain
{
    public class Cliente
    {
        public String Name { get; set; }
        public String fecha { get; set; }
        public Cliente() { }
        public Cliente( String name, String fecha)
        {
            this.Name = name;
            this.fecha = fecha;
        }
    }
}
