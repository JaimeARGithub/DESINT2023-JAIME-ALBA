﻿using Ejercicio1MiguelPelaezDuro.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejercicio1MiguelPelaezDuro.View
{
    /// <summary>
    /// Lógica de interacción para Pagina3.xaml
    /// </summary>
    public partial class Pagina3 : Page
    {
        DataTable tabla1;
        DataTable tabla2;
        DataTable tabla3;
        public Pagina3(List<Trabajo> trabajos, Cliente cliente)
        {
            InitializeComponent();
            tabla1 = new DataTable("DataTable1");
            tabla2 = new DataTable("DataTable2");
            tabla3 = new DataTable("DataTable3");
            tabla3.Columns.Add("TotalFactura");
            tabla2.Columns.Add("Nombre");
            tabla2.Columns.Add("Fecha");
            tabla1.Columns.Add("Horas");
            tabla1.Columns.Add("TrabajoRealizado");
            tabla1.Columns.Add("Precio");
            tabla1.Columns.Add("PrecioTotal");
            Double total = 0;
            DataRow row;
            foreach(Trabajo tb in trabajos)
            { 
                row = tabla1.NewRow();
                row["Horas"] = tb.horas;
                row["TrabajoRealizado"] = tb.trabajoHecho;
                row["Precio"] = tb.precio;
                Double tot = tb.horas * tb.precio;
                row["PrecioTotal"] = tot;
                tabla1 .Rows.Add(row);
                total += tot;
            }
            row = tabla2.NewRow();
            row["Nombre"] = cliente.Name;
            row["Fecha"] = cliente.fecha;
            tabla2.Rows.Add(row);
            row = tabla3.NewRow();
            row["TotalFactura"] = total;
            tabla3.Rows.Add(row);
            CrystalReport1 report = new CrystalReport1();
            report.Database.Tables["DataTable3"].SetDataSource(tabla3);
            report.Database.Tables["DataTable2"].SetDataSource(tabla2);
            report.Database.Tables["DataTable1"].SetDataSource(tabla1);
            visor.ViewerCore.ReportSource = report;


        }
    }
}
