﻿using Ejercicio1MiguelPelaezDuro.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejercicio1MiguelPelaezDuro.View
{
    /// <summary>
    /// Lógica de interacción para Pagina1.xaml
    /// </summary>
    /// <seealso cref="System.Windows.Controls.Page" />
    /// <seealso cref="System.Windows.Markup.IComponentConnector" />
    public partial class Pagina1 : Page
    {
        /// <summary>
        /// The trabajos
        /// </summary>
        public List<Trabajo> trabajos;
        /// <summary>
        /// Initializes a new instance of the <see cref="Pagina1"/> class.
        /// </summary>
        /// <param name="trabajos">The trabajos.</param>
        public Pagina1(List<Trabajo> trabajos)
        {
            InitializeComponent();
            this.trabajos = trabajos;
            dgvTrabajos.ItemsSource = trabajos;
            dgvTrabajos.Items.Refresh();
        }
        /// <summary>
        /// Starts this instance.
        /// </summary>
        public void start()
        {
            tbHoras.Text = "";
            tbPrecio.Text = "";
            tbTrabajo.Text = "";
            dgvTrabajos.UnselectAll();
            trabajos.Clear();
            dgvTrabajos.Items.Refresh();

        }
        /// <summary>
        /// Handles the Click event of the btnAgregar control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void btnAgregar_Click(object sender, RoutedEventArgs e)
        {
            Trabajo trabajo = new Trabajo(int.Parse(tbHoras.Text), tbTrabajo.Text, double.Parse(tbPrecio.Text), false);
            ((List<Trabajo>)dgvTrabajos.ItemsSource).Add(trabajo);
            dgvTrabajos.Items.Refresh();
        }

        /// <summary>
        /// Handles the Click event of the btnPrint control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            Cliente cliente = new Cliente(tbNombre.Text,dtFecha.Text);
            this.NavigationService.Navigate(new Pagina3(trabajos,cliente));
        }

        /// <summary>
        /// Handles the Click event of the btnNew control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            start();
        }

        /// <summary>
        /// Handles the SelectionChanged event of the dgvTrabajos control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="SelectionChangedEventArgs"/> instance containing the event data.</param>
        private void dgvTrabajos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Trabajo tb = (Trabajo)dgvTrabajos.SelectedItems[0];
            tb.estado = "Hecho";
            dgvTrabajos.Items.Refresh();
        }
    }
}
