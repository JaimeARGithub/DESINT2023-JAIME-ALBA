﻿namespace Ejercicio1MiguelPelaezDuro.Persistance
{
}

namespace Ejercicio1MiguelPelaezDuro.Persistance
{


    public partial class DataSet1
    {
    }
}
namespace Ejercicio1MiguelPelaezDuro.Persistance {
    
    
    public partial class DataSet1 {
    }
}
