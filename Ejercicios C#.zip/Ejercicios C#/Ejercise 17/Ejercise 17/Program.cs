﻿
using Ejercise_17;

public class Exercise
{
    public static void Main(string[] args)
    {
        PrintPatterns.a();

        PrintPatterns.b();

        PrintPatterns.c();

        PrintPatterns.d();

        PrintPatterns.e();

        PrintPatterns.f();

        PrintPatterns.g();

        PrintPatterns.h();

        PrintPatterns.i();

        PrintPatterns.j();

        PrintPatterns.k(6);

        PrintPatterns.l(11);

        PrintPatterns.m();

        PrintPatterns.n();

        PrintPatterns.o();

        PrintPatterns.p();

        PrintPatterns.q();

        PrintPatterns.r();

        PrintPatterns.s();

        PrintPatterns.t();

        Console.WriteLine("END OF THE EXERCISE.");
    }
}