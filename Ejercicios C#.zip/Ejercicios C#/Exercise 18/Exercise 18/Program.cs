﻿// See https://aka.ms/new-console-template for more information
using Exercise_18;

public class Programa
{
    public static void Main(string[] args)
    {
        Console.WriteLine(TrigonometricSeries.sin(0));

        Console.WriteLine(TrigonometricSeries.sin(30));

        Console.WriteLine(TrigonometricSeries.sin(60));

        Console.WriteLine(TrigonometricSeries.sin(90));

        Console.WriteLine(TrigonometricSeries.cos(0));

        Console.WriteLine(TrigonometricSeries.cos(30));

        Console.WriteLine(TrigonometricSeries.cos(60));

        Console.WriteLine(TrigonometricSeries.cos(90));
    }
}
