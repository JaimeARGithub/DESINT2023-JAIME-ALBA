﻿int number = 0;
if (number%2==0)
{
    Console.WriteLine("Even number");
} else
{
    Console.WriteLine("Odd number");
}