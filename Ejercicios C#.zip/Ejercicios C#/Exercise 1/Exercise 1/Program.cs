﻿using System;

int mark = 49;
if (mark >= 50)
{
    Console.WriteLine("PASS");

} else
{
    Console.WriteLine("FAIL");

}

